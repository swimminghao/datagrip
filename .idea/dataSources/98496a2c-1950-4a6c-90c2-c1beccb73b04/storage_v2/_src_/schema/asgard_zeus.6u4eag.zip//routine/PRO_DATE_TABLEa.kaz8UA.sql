create
    definer = aesir@`%` procedure PRO_DATE_TABLEa()
BEGIN
	DECLARE V_START_DATE   DATE  DEFAULT DATE_FORMAT('2015-01-01','%Y-%m-%d');
	WHILE V_START_DATE <= DATE_FORMAT('2026-12-31','%Y-%m-%d') DO
       INSERT INTO zeus_date_dict(
			   DATE
			   ,STR_DATE
			   ,LOCAL_DATE
			   ,YEAR
			   ,QUARTER
			   ,MONTH
			   ,DAY
			   ,DAY_OF_YEAR
			   ,DAY_OF_MONTH
			   ,WEEK_OF_YEAR
			   ,WEEK_OF_MONTH
       )SELECT V_START_DATE                       DATE
               ,CONCAT(V_START_DATE,'')           STR_DATE
               ,CONCAT(YEAR(V_START_DATE)  ,'年'
       		           ,MONTH(V_START_DATE),'月'
       			       ,DAY(V_START_DATE)  ,'日') LOCAL_DATE
               ,YEAR(V_START_DATE)                YEAR
			   ,QUARTER(V_START_DATE)       QUARTER
               ,MONTH(V_START_DATE)               MONTH
               ,DAY(V_START_DATE)                 DAY
               ,DAYOFYEAR(V_START_DATE)           DAY_OF_YEAR
               ,DAYOFMONTH(V_START_DATE)          DAY_OF_MONTH
               ,YEARWEEK(V_START_DATE)          WEEK_OF_YEAR
               ,WEEK(V_START_DATE, 0)- WEEK(DATE_SUB(V_START_DATE, INTERVAL DAYOFMONTH(V_START_DATE) - 1 DAY), 0) + 1 WEEK_OF_MONTH
          FROM DUAL;
          SET V_START_DATE = DATE_ADD(V_START_DATE,INTERVAL 1 DAY) ;
	END WHILE;
    END;

