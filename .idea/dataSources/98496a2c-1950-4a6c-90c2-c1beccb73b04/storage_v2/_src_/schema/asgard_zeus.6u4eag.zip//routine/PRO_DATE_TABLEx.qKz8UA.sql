create
    definer = aesir@`%` procedure PRO_DATE_TABLEx()
BEGIN
	DECLARE V_START_DATE   DATE  DEFAULT DATE_FORMAT('2015-01-01','%Y-%m-%d');
	WHILE V_START_DATE <= DATE_FORMAT('2026-12-31','%Y-%m-%d') DO
       INSERT INTO zeus_date_dict(
			   DATE          
			   ,STR_DATE     
			   ,LOCAL_DATE   
			   ,YEAR         
			   ,MONTH        
			   ,DAY          
			   ,DAYOFYEAR  
			   ,DAYOFMONTH 
			   ,WEEKOFYEAR 
			   ,WEEKOFMONTH
       )SELECT V_START_DATE                       DATE 
               ,CONCAT(V_START_DATE,'')           STR_DATE 
               ,CONCAT(YEAR(V_START_DATE)  ,'年'
       		           ,MONTH(V_START_DATE),'月'
       			       ,DAY(V_START_DATE)  ,'日') LOCAL_DATE
               ,YEAR(V_START_DATE)                YEAR
               ,MONTH(V_START_DATE)               MONTH
               ,DAY(V_START_DATE)                 DAY
               ,DAYOFYEAR(V_START_DATE)           DAYOFYEAR 
               ,DAYOFMONTH(V_START_DATE)          DAYOFMONTH
               ,YEARWEEK(V_START_DATE)          WEEKOFYEAR
               ,WEEK(V_START_DATE, 5)- WEEK(DATE_SUB(V_START_DATE, INTERVAL DAYOFMONTH(V_START_DATE) - 1 DAY), 5) + 1 WEEKOFMONTH
          FROM DUAL;
          SET V_START_DATE = DATE_ADD(V_START_DATE,INTERVAL 1 DAY) ;
	END WHILE;
    END;

