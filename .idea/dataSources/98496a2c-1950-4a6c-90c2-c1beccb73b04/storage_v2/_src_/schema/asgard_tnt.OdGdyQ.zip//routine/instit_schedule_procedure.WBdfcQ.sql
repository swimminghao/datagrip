create
    definer = aesir@`%` procedure instit_schedule_procedure()
BEGIN
	SET @current_time = NOW();
	
	/*备份昨天之前的数据*/
	INSERT INTO `t90_instit_schedule_his`
	SELECT * FROM `t90_instit_schedule`
	WHERE DATEDIFF(`schedule_date`,@current_time) < 0;
	/*删除昨天之前的数据*/
	DELETE FROM `t90_instit_schedule`
	WHERE DATEDIFF(`schedule_date`,@current_time) < 0;
	
    END;

