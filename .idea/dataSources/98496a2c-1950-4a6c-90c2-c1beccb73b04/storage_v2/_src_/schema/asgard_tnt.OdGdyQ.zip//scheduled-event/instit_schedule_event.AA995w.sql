create definer = aesir@`%` event instit_schedule_event on schedule
    every '1' DAY
        starts '2019-06-11 21:30:00'
    on completion preserve
    enable
    do
    CALL instit_schedule_procedure();

