create
    definer = aesir@`%` procedure test3()
begin /*  方法开始固定语法*/
    DECLARE i int;/**定义一个变量 控制循环 类似java 中for循环变量 **/
    DECLARE j DOUBLE;
    DECLARE STAFF_CODE DOUBLE;


    set i =0;
    set j =2.13;
    set STAFF_CODE = 'STAFF'||i||'';

    while i<2 DO

      INSERT INTO asgard.T66_COMPANY_STAFF (STAFF_CODE, PLATFORM_NAME, EXAMINEE_NAME, EXAMINEE_PHONE, CERTIFICATE_TYPE, EXAMINEE_ICNO, ACTIVITY_CODE, DEPT_CODE, DEPT_NAME, OPERATOR, COMPANY_NAME, STAFF_STATUS, CREATE_TIME, UPDATE_TIME, STAFF_SEX, COMPANY_STAFF_QUOTA_ID, POST_ADDR, LIMIT_CITY, DEFAULT_CITY, SERVICE_LEVEL, SERVICE_COMMENT, INSURANCE_CLICK_STATUS) VALUES (STAFF_CODE, 'SHANZHEN', '翟测', '13917795634', 1, '310115198003206172', 'ACT074360112', null, null, '翟聪敏', '测试', -1, '2019-04-24 16:05:22', '2019-04-24 16:05:22', null, null, null, null, null, 1, null, 0);


      set i = i+1;
     
    end while;
  end;

