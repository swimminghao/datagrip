create
    definer = aesir@`%` procedure test_family_order()
begin
  declare row_gid int ;
  declare row_name varchar(20);
  declare row_num int;
  select 'hello';
end;

