create
    definer = aesir@`%` procedure prod_data_clean_goods_feature()
BEGIN
	-- 定义判断变量
	DECLARE _flag varchar(50);
	DECLARE _FEATURE_NAME varchar(255);
	DECLARE _FEATURE_IMG_URL varchar(255);
	DECLARE _FEATURE_TYPE tinyint(4);
	DECLARE _FEATURE_DESC varchar(255);
	DECLARE _REMARK varchar(512);
	DECLARE _SZ_STATUS tinyint(4);
	DECLARE _SHOW_ORDER tinyint(4);
	DECLARE _ID long;
	-- 遍历数据结束标志
    DECLARE done INT DEFAULT TRUE;
    -- 游标
    DECLARE cur_account CURSOR FOR 
    select tpf.FEATURE_NAME,tpf.FEATURE_IMG_URL,tpf.FEATURE_TYPE,tpf.FEATURE_DESC,tpf.REMARK,tpf.SZ_STATUS,tpf.SHOW_ORDER from T66_PRODUCT_FEATURE tpf
		left join T66_GOODS tg on tpf.PRODUCT_CODE=tg.PRODUCT_CODE
		where tg.GOODS_CODE=_flag;

	-- 定义查询变量
	DECLARE _cur CURSOR FOR 
		SELECT distinct GOODS_CODE FROM T66_SZ_ACTIVITY_MAP_PRODUCT 
		WHERE GOODS_BIZ_TYPE = 1 AND STATUS =1 and goods_code is not null and ltrim(rtrim(goods_code)) <> '' ;
	-- 定义数据结束的条件值
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = FALSE;

	-- 打开
	OPEN _cur;

	-- 循环判断
	 WHILE done DO
	 	-- 赋值
		FETCH _cur INTO _flag;
		
		IF done = TRUE THEN
			-- select _flag;  
			-- 打开游标
	    OPEN  cur_account;     
	    
	   
	    -- 遍历
	   WHILE done DO
			 -- 取值 取多个字段
	    FETCH  cur_account INTO _FEATURE_NAME,_FEATURE_IMG_URL,_FEATURE_TYPE,_FEATURE_DESC,_REMARK,_SZ_STATUS,_SHOW_ORDER;
	    -- 是否还有数据的标识
          IF done = TRUE THEN             	            
		             	            
	        		-- 插入数据
	        		INSERT INTO `T66_GOODS_FEATURE` (`FEATURE_NAME`, `FEATURE_IMG_URL`, `FEATURE_TYPE`, `FEATURE_DESC`, `REMARK`, `SZ_STATUS`, `CREATE_TIME`, `UPDATE_TIME`) 
	        		values (_FEATURE_NAME,_FEATURE_IMG_URL,_FEATURE_TYPE,_FEATURE_DESC,_REMARK,_SZ_STATUS,NOW(),NOW());
	        		select @@IDENTITY into _ID;
					INSERT INTO `T66_GOODS_MAP_FEATURE` (`GOODS_CODE`, `FEATURE_ID`, `SHOW_ORDER`, `REMARK`, `SZ_STATUS`, `CREATE_TIME`, `UPDATE_TIME`) 
					values (_flag,_ID,_SHOW_ORDER,_REMARK,_SZ_STATUS,NOW(),NOW());
	    
			END IF;
		 
		 END WHILE;
			## 关闭
		CLOSE cur_account;
	
		-- 游标没有数据之后done会变成FALSE，这里要手动改回来，外层循环才会继续
        SET done = TRUE;
      END IF;
	END WHILE;
	## 关闭
	CLOSE _cur;
 
END;

