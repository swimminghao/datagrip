create
    definer = aesir@`%` procedure test4()
begin /*  方法开始固定语法*/
    DECLARE i int;/**定义一个变量 控制循环 类似java 中for循环变量 **/
    DECLARE deal_code varchar(30);
   DECLARE docking_order_code varchar(30);
	    DECLARE partner_order_code varchar(30);
				    DECLARE examinee_phone varchar(30);


    set i =0;

    while i<19200 DO
    set docking_order_code = CONCAT('SZ',FLOOR(12 + (RAND() * 1*10000000*10000000))+i );

    set deal_code = CONCAT('19051722',FLOOR(13 + (RAND() * 1*10000000*10000000))+i );
		    set partner_order_code = FLOOR(12 + (RAND() * 1*1000*10000)) ;
		    set examinee_phone = FLOOR(12 + (RAND() * 1*1000*10000))+i ;

INSERT INTO asgard_tnt.t90_pre_docking_order (docking_order_code, partner_order_code, out_order_code, docking_sys_code, purchase_channel_code, purchase_channel_name, examinee_name, examinee_phone, reserve_time, ope_reserve_time, certificate_type, examinee_icno, examinee_birthday, examinee_gender, partner_product_code, partner_product_name, partner_instit_code, partner_instit_name, out_instit_code, out_instit_name, partner_pkg_code, partner_pkg_name, out_pkg_code, out_pkg_name, partner_add_pkg_codes, partner_add_pkg_names, partner_add_product_codes, partner_add_product_names, out_add_pkg_codes, out_add_pkg_names, docking_status, docking_type, process_status, status, card_no, card_pwd, off_order_code, out_sys_code, create_time, update_time, remark)
VALUES (docking_order_code, partner_order_code, null, '1', 'PCL610619341', '普惠西安', '翟测试', examinee_phone, '2019-05-27 00:00:00', '2019-05-16 20:43:31', 1, '110101199003070038', '19900307', 'M', 'PDT406524406', '美年测试上报产品-1120', 'INS776710629', '西安普惠经开体检分院', null, null, 'PKG859444010', '美年测试上报套餐1-男', null, null, null, null, null, null, null, null, 0, 1, 0, 1, null, null, null, null, SYSDATE(), SYSDATE(), null);

INSERT INTO asgard_tnt.t90_pre_docking_deal_info (deal_code, docking_order_code, partner_order_code, purchase_channel_code, purchase_channel_name, partner_product_code, partner_product_name, partner_instit_code, partner_instit_name, partner_add_pkg_codes, partner_add_pkg_names, partner_add_product_codes, partner_add_product_names, out_instit_code, out_instit_name, examinee_phone, examinee_icno, examinee_birthday, examinee_gender, reserve_time, certificate_type, docking_classify, docking_type, out_pkg_code, out_pkg_name, out_add_pkg_codes, out_add_pkg_names, examinee_name, partner_pkg_code, partner_pkg_name, docking_status, ready_docking_send_time, docking_send_time, review_status, order_cost, email_template_id, email_send_time, process_status, docking_level, docking_result, instit_brand, docking_rules, status, version, examinee_city, out_order_code, card_no, check_no, pdf_extract_status, structured_data_extract_status, card_pwd, out_sys_code, off_order_code, create_time, update_time, remark)
VALUES (deal_code, docking_order_code, partner_order_code, 'PCL610619341', '普惠西安', 'PDT406524406', '美年测试上报产品-1120', 'INS776710629', '西安普惠经开体检分院', null, null, null, null, null, null, examinee_phone, '110101199003070038', '19900307', 'M', '2019-05-27 00:00:00', 1, 2, 1, null, null, null, null, '翟测试', 'PKG859444010', '美年测试上报套餐1-男', 0, SYSDATE(), null, 0, null, 20, SYSDATE(), 0, 1, null, null, null, 1, 0, null, null, null, null, 0, 0, null, null, null, SYSDATE(), SYSDATE(), null);

    set i = i+1;
     
    end while;
  end;

